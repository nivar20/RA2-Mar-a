﻿namespace Proyecto_Final_Base_De_Datos
{
    partial class F_Factura
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_Factura));
            label2 = new Label();
            btn_Principal = new Button();
            txt_Empleado_Factura = new TextBox();
            txt_Total_Factura = new TextBox();
            txt_Fecha_Factura = new TextBox();
            txt_Precio_Factura = new TextBox();
            txt_Cliente_Factura = new TextBox();
            txt_Id_Factura = new TextBox();
            txt_Producto_Factura = new TextBox();
            txt_Cantidad_Factura = new TextBox();
            PRODUCTO = new Label();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label1 = new Label();
            Apellido_Empleado = new Label();
            IDENTIFICACION = new Label();
            btn_Selet = new Button();
            panel1 = new Panel();
            btn_Eliminar = new Button();
            btn_Actualizar = new Button();
            btn_Guardar = new Button();
            panel2 = new Panel();
            dateTimePicker1 = new DateTimePicker();
            pictureBox5 = new PictureBox();
            label12 = new Label();
            dgv_principal = new DataGridView();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)dgv_principal).BeginInit();
            SuspendLayout();
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft Sans Serif", 17.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            label2.Location = new Point(49, 0);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(299, 40);
            label2.TabIndex = 2;
            label2.Text = "Registro Factura";
            // 
            // btn_Principal
            // 
            btn_Principal.BackColor = SystemColors.MenuHighlight;
            btn_Principal.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Principal.ForeColor = SystemColors.ButtonHighlight;
            btn_Principal.Location = new Point(263, 488);
            btn_Principal.Margin = new Padding(4, 5, 4, 5);
            btn_Principal.Name = "btn_Principal";
            btn_Principal.Size = new Size(263, 47);
            btn_Principal.TabIndex = 5;
            btn_Principal.Text = "PRINCIPAL";
            btn_Principal.UseVisualStyleBackColor = false;
            btn_Principal.Click += btn_Principal_Click;
            // 
            // txt_Empleado_Factura
            // 
            txt_Empleado_Factura.Location = new Point(10, 485);
            txt_Empleado_Factura.Margin = new Padding(4, 5, 4, 5);
            txt_Empleado_Factura.Name = "txt_Empleado_Factura";
            txt_Empleado_Factura.Size = new Size(287, 31);
            txt_Empleado_Factura.TabIndex = 71;
            // 
            // txt_Total_Factura
            // 
            txt_Total_Factura.Location = new Point(11, 576);
            txt_Total_Factura.Margin = new Padding(4, 5, 4, 5);
            txt_Total_Factura.Name = "txt_Total_Factura";
            txt_Total_Factura.Size = new Size(288, 31);
            txt_Total_Factura.TabIndex = 70;
            // 
            // txt_Fecha_Factura
            // 
            txt_Fecha_Factura.Location = new Point(11, 663);
            txt_Fecha_Factura.Margin = new Padding(4, 5, 4, 5);
            txt_Fecha_Factura.Name = "txt_Fecha_Factura";
            txt_Fecha_Factura.Size = new Size(288, 31);
            txt_Fecha_Factura.TabIndex = 69;
            // 
            // txt_Precio_Factura
            // 
            txt_Precio_Factura.Location = new Point(11, 232);
            txt_Precio_Factura.Margin = new Padding(4, 5, 4, 5);
            txt_Precio_Factura.Name = "txt_Precio_Factura";
            txt_Precio_Factura.Size = new Size(281, 31);
            txt_Precio_Factura.TabIndex = 68;
            // 
            // txt_Cliente_Factura
            // 
            txt_Cliente_Factura.Location = new Point(10, 402);
            txt_Cliente_Factura.Margin = new Padding(4, 5, 4, 5);
            txt_Cliente_Factura.Name = "txt_Cliente_Factura";
            txt_Cliente_Factura.Size = new Size(287, 31);
            txt_Cliente_Factura.TabIndex = 67;
            // 
            // txt_Id_Factura
            // 
            txt_Id_Factura.Location = new Point(23, 55);
            txt_Id_Factura.Margin = new Padding(4, 5, 4, 5);
            txt_Id_Factura.Name = "txt_Id_Factura";
            txt_Id_Factura.Size = new Size(281, 31);
            txt_Id_Factura.TabIndex = 66;
            // 
            // txt_Producto_Factura
            // 
            txt_Producto_Factura.Location = new Point(16, 149);
            txt_Producto_Factura.Margin = new Padding(4, 5, 4, 5);
            txt_Producto_Factura.Name = "txt_Producto_Factura";
            txt_Producto_Factura.Size = new Size(281, 31);
            txt_Producto_Factura.TabIndex = 65;
            // 
            // txt_Cantidad_Factura
            // 
            txt_Cantidad_Factura.Location = new Point(11, 318);
            txt_Cantidad_Factura.Margin = new Padding(4, 5, 4, 5);
            txt_Cantidad_Factura.Name = "txt_Cantidad_Factura";
            txt_Cantidad_Factura.Size = new Size(281, 31);
            txt_Cantidad_Factura.TabIndex = 63;
            // 
            // PRODUCTO
            // 
            PRODUCTO.AutoSize = true;
            PRODUCTO.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            PRODUCTO.Location = new Point(17, 101);
            PRODUCTO.Margin = new Padding(4, 0, 4, 0);
            PRODUCTO.Name = "PRODUCTO";
            PRODUCTO.Size = new Size(190, 33);
            PRODUCTO.TabIndex = 61;
            PRODUCTO.Text = "PRODUCTO";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label7.Location = new Point(11, 538);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(114, 33);
            label7.TabIndex = 60;
            label7.Text = "TOTAL";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label6.Location = new Point(17, 447);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(183, 33);
            label6.TabIndex = 59;
            label6.Text = "EMPLEADO";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label5.Location = new Point(11, 621);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(118, 33);
            label5.TabIndex = 58;
            label5.Text = "FECHA";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(16, 354);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(144, 33);
            label4.TabIndex = 57;
            label4.Text = "CLIENTE";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(16, 280);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(171, 33);
            label1.TabIndex = 56;
            label1.Text = "CANTIDAD";
            // 
            // Apellido_Empleado
            // 
            Apellido_Empleado.AutoSize = true;
            Apellido_Empleado.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            Apellido_Empleado.Location = new Point(16, 194);
            Apellido_Empleado.Margin = new Padding(4, 0, 4, 0);
            Apellido_Empleado.Name = "Apellido_Empleado";
            Apellido_Empleado.Size = new Size(132, 33);
            Apellido_Empleado.TabIndex = 55;
            Apellido_Empleado.Text = "PRECIO";
            // 
            // IDENTIFICACION
            // 
            IDENTIFICACION.AutoSize = true;
            IDENTIFICACION.Font = new Font("Microsoft Sans Serif", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            IDENTIFICACION.Location = new Point(23, 12);
            IDENTIFICACION.Margin = new Padding(4, 0, 4, 0);
            IDENTIFICACION.Name = "IDENTIFICACION";
            IDENTIFICACION.Size = new Size(46, 33);
            IDENTIFICACION.TabIndex = 54;
            IDENTIFICACION.Text = "ID";
            // 
            // btn_Selet
            // 
            btn_Selet.BackColor = SystemColors.MenuHighlight;
            btn_Selet.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Selet.ForeColor = SystemColors.ButtonHighlight;
            btn_Selet.Location = new Point(23, 704);
            btn_Selet.Margin = new Padding(4, 5, 4, 5);
            btn_Selet.Name = "btn_Selet";
            btn_Selet.Size = new Size(263, 47);
            btn_Selet.TabIndex = 72;
            btn_Selet.Text = "LISTAR";
            btn_Selet.UseVisualStyleBackColor = false;
            btn_Selet.Click += btn_Selet_Click;
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightSkyBlue;
            panel1.Controls.Add(btn_Eliminar);
            panel1.Controls.Add(btn_Actualizar);
            panel1.Controls.Add(btn_Selet);
            panel1.Controls.Add(txt_Fecha_Factura);
            panel1.Controls.Add(txt_Total_Factura);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(txt_Empleado_Factura);
            panel1.Controls.Add(btn_Guardar);
            panel1.Controls.Add(IDENTIFICACION);
            panel1.Controls.Add(txt_Id_Factura);
            panel1.Controls.Add(txt_Cliente_Factura);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(txt_Precio_Factura);
            panel1.Controls.Add(txt_Cantidad_Factura);
            panel1.Controls.Add(PRODUCTO);
            panel1.Controls.Add(txt_Producto_Factura);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(Apellido_Empleado);
            panel1.Controls.Add(label1);
            panel1.Location = new Point(6, 45);
            panel1.Margin = new Padding(4, 5, 4, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(379, 1055);
            panel1.TabIndex = 75;
            panel1.Paint += panel1_Paint;
            // 
            // btn_Eliminar
            // 
            btn_Eliminar.BackColor = SystemColors.MenuHighlight;
            btn_Eliminar.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Eliminar.ForeColor = SystemColors.ButtonHighlight;
            btn_Eliminar.Location = new Point(23, 884);
            btn_Eliminar.Margin = new Padding(4, 5, 4, 5);
            btn_Eliminar.Name = "btn_Eliminar";
            btn_Eliminar.Size = new Size(263, 47);
            btn_Eliminar.TabIndex = 77;
            btn_Eliminar.Text = "ELIMINAR";
            btn_Eliminar.UseVisualStyleBackColor = false;
            btn_Eliminar.Click += btn_Eliminar_Click;
            // 
            // btn_Actualizar
            // 
            btn_Actualizar.BackColor = SystemColors.MenuHighlight;
            btn_Actualizar.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Actualizar.ForeColor = SystemColors.ButtonHighlight;
            btn_Actualizar.Location = new Point(23, 818);
            btn_Actualizar.Margin = new Padding(4, 5, 4, 5);
            btn_Actualizar.Name = "btn_Actualizar";
            btn_Actualizar.Size = new Size(263, 47);
            btn_Actualizar.TabIndex = 76;
            btn_Actualizar.Text = "ACTUALIZAR";
            btn_Actualizar.UseVisualStyleBackColor = false;
            btn_Actualizar.Click += btn_Actualizar_Click;
            // 
            // btn_Guardar
            // 
            btn_Guardar.BackColor = SystemColors.MenuHighlight;
            btn_Guardar.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Guardar.ForeColor = SystemColors.ButtonHighlight;
            btn_Guardar.Location = new Point(23, 761);
            btn_Guardar.Margin = new Padding(4, 5, 4, 5);
            btn_Guardar.Name = "btn_Guardar";
            btn_Guardar.Size = new Size(263, 47);
            btn_Guardar.TabIndex = 25;
            btn_Guardar.Text = "GUARDAR";
            btn_Guardar.UseVisualStyleBackColor = false;
            btn_Guardar.Click += btn_Guardar_Click;
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightBlue;
            panel2.Controls.Add(dateTimePicker1);
            panel2.Controls.Add(pictureBox5);
            panel2.Controls.Add(label12);
            panel2.Controls.Add(dgv_principal);
            panel2.Controls.Add(btn_Principal);
            panel2.Location = new Point(403, 14);
            panel2.Margin = new Padding(4, 5, 4, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(801, 725);
            panel2.TabIndex = 74;
            panel2.Paint += panel2_Paint;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(233, 20);
            dateTimePicker1.Margin = new Padding(4, 5, 4, 5);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(331, 31);
            dateTimePicker1.TabIndex = 76;
            // 
            // pictureBox5
            // 
            pictureBox5.BackgroundImageLayout = ImageLayout.None;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(658, 20);
            pictureBox5.Margin = new Padding(4, 5, 4, 5);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(127, 112);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 76;
            pictureBox5.TabStop = false;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Microsoft Sans Serif", 17.9999981F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(299, 87);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(177, 40);
            label12.TabIndex = 8;
            label12.Text = "LISTADO";
            // 
            // dgv_principal
            // 
            dgv_principal.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_principal.Location = new Point(11, 158);
            dgv_principal.Margin = new Padding(4, 5, 4, 5);
            dgv_principal.Name = "dgv_principal";
            dgv_principal.RowHeadersWidth = 62;
            dgv_principal.RowTemplate.Height = 25;
            dgv_principal.Size = new Size(773, 275);
            dgv_principal.TabIndex = 16;
            dgv_principal.CellClick += dgv_principal_CellClick;
            // 
            // F_Factura
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.LightBlue;
            ClientSize = new Size(1207, 1050);
            Controls.Add(panel1);
            Controls.Add(panel2);
            Controls.Add(label2);
            Margin = new Padding(4, 5, 4, 5);
            Name = "F_Factura";
            Text = "F_Factura";
            Load += F_Factura_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)dgv_principal).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label2;
        private Button btn_Principal;
        private Button btn_Selet;
        private TextBox txt_Direccion_Empleado;
        private TextBox txt_Cargo_Empleado;
        private TextBox txt_Telefono_Empleado;
        private TextBox txt_Apellido_Empleado;
        private TextBox txt_Cedula_Empleado;
        private TextBox txt_Id_Empleado;
        private TextBox txt_Nombre_Empleado;
        private TextBox txt_Sueldo_Empleado;
        private TextBox txt_Edad_Empleado;
        private Label PRODUCTO;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label1;
        private Label Apellido_Empleado;
        private Label IDENTIFICACION;
        private TextBox txt_Empleado_Factura;
        private TextBox txt_Total_Empleado;
        private TextBox txt_Fecha_Factura;
        private TextBox txt_Precio_Factura;
        private TextBox txt_Cliente_Factura;
        private TextBox txt_Id_FACTURA;
        private TextBox txt_Producto_Factura;
        private TextBox txt_Cantidad_Factura;
        private TextBox txt_Id_Factura;
        private TextBox txt_Total_Factura;
        private Panel panel1;
        private Button btn_Guardar;
        private Panel panel2;
        private Label label12;
        private DataGridView dgv_principal;
        private PictureBox pictureBox5;
        private DateTimePicker dateTimePicker1;
        private Button btn_Eliminar;
        private Button btn_Actualizar;
    }
}