﻿namespace Proyecto_Final_Base_De_Datos
{
    partial class F_Principal
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(F_Principal));
            panel1 = new Panel();
            pictureBox6 = new PictureBox();
            pictureBox5 = new PictureBox();
            pictureBox1 = new PictureBox();
            pictureBox4 = new PictureBox();
            pictureBox3 = new PictureBox();
            btn_Inventario = new Button();
            btn_Factura = new Button();
            btn_Cliente = new Button();
            btn_Empleado = new Button();
            panel2 = new Panel();
            label1 = new Label();
            dateTimePicker1 = new DateTimePicker();
            pictureBox2 = new PictureBox();
            imageList1 = new ImageList(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.LightBlue;
            panel1.Controls.Add(pictureBox6);
            panel1.Controls.Add(pictureBox5);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(pictureBox4);
            panel1.Controls.Add(pictureBox3);
            panel1.Controls.Add(btn_Inventario);
            panel1.Controls.Add(btn_Factura);
            panel1.Controls.Add(btn_Cliente);
            panel1.Controls.Add(btn_Empleado);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 5, 4, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(366, 750);
            panel1.TabIndex = 0;
            // 
            // pictureBox6
            // 
            pictureBox6.BackgroundImageLayout = ImageLayout.None;
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(13, 462);
            pictureBox6.Margin = new Padding(4, 5, 4, 5);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(114, 93);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 6;
            pictureBox6.TabStop = false;
            // 
            // pictureBox5
            // 
            pictureBox5.BackgroundImageLayout = ImageLayout.None;
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(17, 612);
            pictureBox5.Margin = new Padding(4, 5, 4, 5);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(115, 112);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox5.TabIndex = 5;
            pictureBox5.TabStop = false;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(40, 18);
            pictureBox1.Margin = new Padding(4, 5, 4, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(255, 155);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 2;
            pictureBox1.TabStop = false;
            // 
            // pictureBox4
            // 
            pictureBox4.BackgroundImageLayout = ImageLayout.None;
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(13, 183);
            pictureBox4.Margin = new Padding(4, 5, 4, 5);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(118, 110);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox4.TabIndex = 4;
            pictureBox4.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.BackgroundImageLayout = ImageLayout.None;
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(13, 303);
            pictureBox3.Margin = new Padding(4, 5, 4, 5);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(119, 113);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox3.TabIndex = 3;
            pictureBox3.TabStop = false;
            // 
            // btn_Inventario
            // 
            btn_Inventario.BackColor = SystemColors.MenuHighlight;
            btn_Inventario.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Inventario.ForeColor = SystemColors.ButtonHighlight;
            btn_Inventario.Location = new Point(140, 474);
            btn_Inventario.Margin = new Padding(4, 5, 4, 5);
            btn_Inventario.Name = "btn_Inventario";
            btn_Inventario.Size = new Size(216, 50);
            btn_Inventario.TabIndex = 3;
            btn_Inventario.Text = "Inventario";
            btn_Inventario.UseVisualStyleBackColor = false;
            btn_Inventario.Click += btn_Inventario_Click_1;
            // 
            // btn_Factura
            // 
            btn_Factura.BackColor = SystemColors.MenuHighlight;
            btn_Factura.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Factura.ForeColor = SystemColors.ButtonHighlight;
            btn_Factura.Location = new Point(140, 644);
            btn_Factura.Margin = new Padding(4, 5, 4, 5);
            btn_Factura.Name = "btn_Factura";
            btn_Factura.Size = new Size(216, 47);
            btn_Factura.TabIndex = 2;
            btn_Factura.Text = "Factura";
            btn_Factura.UseVisualStyleBackColor = false;
            btn_Factura.Click += btn_Factura_Click_1;
            // 
            // btn_Cliente
            // 
            btn_Cliente.BackColor = SystemColors.MenuHighlight;
            btn_Cliente.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Cliente.ForeColor = SystemColors.ButtonHighlight;
            btn_Cliente.Location = new Point(140, 213);
            btn_Cliente.Margin = new Padding(4, 5, 4, 5);
            btn_Cliente.Name = "btn_Cliente";
            btn_Cliente.Size = new Size(216, 47);
            btn_Cliente.TabIndex = 0;
            btn_Cliente.Text = "Cliente";
            btn_Cliente.UseVisualStyleBackColor = false;
            btn_Cliente.Click += btn_Cliente_Click_1;
            // 
            // btn_Empleado
            // 
            btn_Empleado.BackColor = SystemColors.MenuHighlight;
            btn_Empleado.Font = new Font("Stencil", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
            btn_Empleado.ForeColor = SystemColors.ButtonHighlight;
            btn_Empleado.Location = new Point(140, 333);
            btn_Empleado.Margin = new Padding(4, 5, 4, 5);
            btn_Empleado.Name = "btn_Empleado";
            btn_Empleado.Size = new Size(216, 47);
            btn_Empleado.TabIndex = 1;
            btn_Empleado.Text = "Empleado";
            btn_Empleado.UseVisualStyleBackColor = false;
            btn_Empleado.Click += btn_Empleado_Click_1;
            // 
            // panel2
            // 
            panel2.BackColor = Color.White;
            panel2.Controls.Add(label1);
            panel2.Controls.Add(dateTimePicker1);
            panel2.Controls.Add(pictureBox2);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(366, 0);
            panel2.Margin = new Padding(4, 5, 4, 5);
            panel2.Name = "panel2";
            panel2.Size = new Size(811, 70);
            panel2.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Times New Roman", 16F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(158, 24);
            label1.Name = "label1";
            label1.Size = new Size(231, 36);
            label1.TabIndex = 2;
            label1.Text = "Menú Principal";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(500, 18);
            dateTimePicker1.Margin = new Padding(4, 5, 4, 5);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(305, 31);
            dateTimePicker1.TabIndex = 2;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(9, 5);
            pictureBox2.Margin = new Padding(4, 5, 4, 5);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(57, 60);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox2.TabIndex = 4;
            pictureBox2.TabStop = false;
            // 
            // imageList1
            // 
            imageList1.ColorDepth = ColorDepth.Depth8Bit;
            imageList1.ImageSize = new Size(16, 16);
            imageList1.TransparentColor = Color.Transparent;
            // 
            // F_Principal
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            BackgroundImage = Properties.Resources.Imagen_de_WhatsApp_2024_05_02_a_las_13_25_01_e854eee1;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(1177, 750);
            Controls.Add(panel2);
            Controls.Add(panel1);
            Margin = new Padding(4, 5, 4, 5);
            Name = "F_Principal";
            Text = "Formulario_Principal";
            panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel2.ResumeLayout(false);
            panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Button btn_Inventario;
        private Button btn_Factura;
        private Button btn_Empleado;
        private Button btn_Cliente;
        private Panel panel2;
        private ImageList imageList1;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
        private DateTimePicker dateTimePicker1;
        private PictureBox pictureBox4;
        private PictureBox pictureBox3;
        private PictureBox pictureBox5;
        private PictureBox pictureBox6;
        private Label label1;
    }
}